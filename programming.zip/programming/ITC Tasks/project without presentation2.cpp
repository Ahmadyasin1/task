#include <iostream>
using namespace std;
int main()
{
	cout << "\x1b[1;3;4m				Project Presentation ITC\n				Name:	Ahmad Yasin\n				Reg.:	L1F22BSAI0052\n\n\n\x1b[0m";
	int Array1[7]/*for monkey1*/, Array2[7]/*for monkey2*/, Array3[7]/*for monkey3*/, Array4[7]/*for sum of Array[1;2;3]*/, Array5[25]/*for data of Array[1;2;3]*/, sum = 0/*to find sum*/, a = 0/*for count*/; double Average/*to find average*/;
	cout << "\x1b[1;3;4m(Please Enter +ve Number Only)\n\x1b[0m";
	for (int i = 0; i < 7; i++)
	{
		cout << "Day " << i + 1 << ":- \n";//Enter Day with numbers
		cout << "Monkey1:  ";
		cin >> Array1[i];//Take entry for Monkey1 from user
		cout << "Monkey2:  ";
		cin >> Array2[i];//Take entry for Monkey2 from user
		cout << "Monkey3:  ";
		cin >> Array3[i];//Take entry for Monkey3 from user
		Array4[i] = Array1[i] + Array2[i] + Array3[i];//sum of all Arrays
		Array5[i] = Array1[i];//Put Array1 into Array 5
		Array5[i + 7] = Array2[i];//Put Array2 into Array 5
		Array5[i + 14] = Array3[i];//Put Array3 into Array 5
		sum = sum + Array4[i];//Take sum of Array4
		a++;//To find count
	}
	Average = sum / a;//To find Average
	int c = Array5[0], e = Array5[0];
	for (int i = 0; i < 21; i++)//To Check the greatest and smallest value in data from array5
	{
		if (Array5[i] > 0)//To cheack +ve value
		{
			if (Array5[i] < c)//To cheack Least value
			{
				c = Array5[i];
			}
			if (Array5[i] > e)//To cheack greatest value
			{
				e = Array5[i];
			}
		}
		else//If user enter -ve value then this show error
		{
			cout << "	Error!!!\n	You Enter -ve Number\n\n\n";
			return 0;
		}
	}
	cout << "\nAverage amount of food eaten per day by the whole family of monkeys is:	" << Average; if (Average > 1) { cout << " pounds" << endl; }else { cout << " pound" << endl; }
	cout << "The least amount of food eaten during the week by any one monkey is:	" << c; if (c > 1) { cout << " pounds" << endl; }else { cout << " pound" << endl; }
	cout << "The greatest amount of food eaten during the week by any one monkey is:	" << e; if (e > 1) { cout << " pounds" << endl; }else { cout << " pound" << endl; }
	cout << "\n\n\x1b[1;3;5m					Presented By Ahmad Yasin.\x1b[0m\n\n\n";
	return 0;
}