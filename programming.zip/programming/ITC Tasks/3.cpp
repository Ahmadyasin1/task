#include <iostream>
using namespace std;
int main()
{
	double x[12] = { 3.2,2.2,1.5,3.4,0,1.2,1,2.5,1.5,2.9,0,3.5 };
	double y[12] = { 4,1.6,2,1.9,0,0,1,3.9,0.5,2,1.5,4 };
	char z[13][10] = { "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec","\0" };
	double a = 0, b = 0, avr1, avr2, Highest1 = x[0], Highest2 = y[0];
	//To write month
	cout << "		";
	for (int i = 0; i < 12; i++)
	{
		cout << z[i] << "	";
	}
	//To write data of this year
	cout << "\nThis Year:	";
	for (int i = 0; i < 12; i++)
	{
		a = a + x[i];
		cout << x[i] << "	";
	}
	//To write data for last year
	cout << "\nLast Year:	";
	for (int i = 0; i < 12; i++)
	{
		b = b + y[i];
		cout << y[i] << "	";
	}
	//To find Greatest value
	for (int i = 0; i < 12; i++)
	{
		if (x[i] > Highest1)
		{
			Highest1 = x[i];
		}
		if (y[i] > Highest2)
		{
			Highest2 = y[i];
		}
	}
	//To find Avrage
	avr1 = a / 12;
	avr2 = b / 12;


	cout << "\n\n\nTotal rainfall this year: " << a;
	cout << "\nTotal rainfall last year: " << b;
	cout << "\nAverage monthly rainfall this year: " << avr1;
	cout << "\nAverage monthly rainfall last year: " << avr2;
	cout << "\nHighest rainfall this year: " << Highest1;
	cout << "\nHighest rainfall last year: " << Highest2;
	cout << "\nMonth having no rainfall this year: ";
	//To chack the nothing Rainfall for this year
	for (int k = 0; k < 12; k++)
	{
		if (x[k] == 0)
		{
			cout << z[k] << ", ";
		}
	}
	cout << "\nMonth having no rainfall last year: ";
	//To chack the nothing Rainfall for this year
	for (int k = 0; k < 12; k++)
	{
		if (y[k] == 0)
		{
			cout << z[k] << ", ";
		}
	}
	return 0;
}