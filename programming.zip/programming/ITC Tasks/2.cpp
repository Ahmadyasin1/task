#include <iostream>


using namespace std;


int main() {
    int choice, amount;

    int balance = 2000;

    cout << "Please choose an option:" << endl;

    cout << "1. Deposit" << endl;

    cout << "2. Withdraw" << endl;

    cout << "3. Transfer" << endl;

    cout << "4. Check balance" << endl;

    cout << "5. Exit" << endl;

    cout << "Enter choice: ";

    cin >> choice;

    if (choice == 1) {

        cout << "Enter amount to deposit: ";
        cin >> amount;
        balance += amount;
        cout << "Deposit successful. Current balance: " << balance << endl;
    }

    else if (choice == 2) {

        cout << "Enter amount to withdraw: ";
        cin >> amount;
        if (balance - amount < 0) {
            cout << "Insufficient balance." << endl;
        }
        else {
            balance -= amount;
            cout << "Withdrawal successful. Current balance: " << balance << endl;
        }
    }
    else if (choice == 3) {

        cout << "Enter amount to transfer: ";
        cin >> amount;
        if (balance - amount < 0) {
            cout << "Insufficient balance." << endl;
        }
        else {
            balance -= amount;
            cout << "Transfer successful. Current balance: " << balance << endl;
        }
    }

    else if (choice == 4) {

        cout << "Current balance: " << balance << endl;
    }
    else if (choice == 5) {

        cout << "Thank you for using our ATM." << endl;
    }
    else {

        cout << "Invalid choice. Please try again." << endl;
    }
    return 0;
}