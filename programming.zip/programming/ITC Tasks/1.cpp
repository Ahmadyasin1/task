#include<iostream>
using namespace std;
int main()
{
	char array1[20] = { 'A','D','B','B','C','B','A','B','C','D','A','C','D','B','D','C','C','A','D','B' };//These are the solution of all Questions
	char array2[20];// to take the answers from user
	int a = 1;// To find the Correct Answer
	int b = 68, c = 65;
	cout << "Enter The Corerect Answers of Following Questions.\n";
	for (int i = 0; i < 20; i++)//take the entry from user
	{
		cout << "\nQuestion # " << i + 1 << endl;//to tell the question number
		cin >> array2[i];
	}
	for (int j = 0; j < 20; j++)// To find the solution
	{
		if (array2[j] >= c && array2[j] <= b)
		{
			if (array1[j] == array2[j])// To compare the user entry with Array 1
			{
				a++;// To Check Corrct Ans 
			}
		}
		else//IF user enter rather than (A,B,C,D)
		{
			cout << "You enter wrong entry which is rather than (A,B,C,D).\n Please try again and wright correct answers";
			return 0;
		}
	}
	cout << "Corect Answer is:- " << a << endl;
	cout << "Incorect Answer is:- " << 20 - a << endl;
	if (a > 15)// Pass or Fail
	{
		cout << "You Pass the Exam";
	}
	else
	{
		cout << "You'r Fail in Exam\nPlease try again later.";
	}
	return 0;
}
