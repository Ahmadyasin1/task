//#include<iostream>
//#include<fstream>
//using namespace std;
//
//int* newDynamic1D(int s);
//int* regrow(int*oldarray,int&s,int v);
//void copy(int* newarray, int* oldarray, int s);
//void display(int*p,int s);
//void deleteDynamic1D(int* p);
//
//int main()
//{
//	ifstream read;
//	read.open("input.txt");
//	if (!read)
//	{
//		cout << "File not found!...\n";
//	}
//	else
//	{
//		int s = 0,n;
//		int* p = newDynamic1D(s+1);
//		read >> n;
//		p[s] = n;
//		s++;
//		while (read>>n)
//		{
//			p = regrow(p,s,n);
//		}
//		display(p,s);
//	}
//
//	return 0;
//}
//
//int* newDynamic1D(int s)
//{
//	int* n = new int[s];
//	return n;
//}
//int* regrow(int* oldarray, int& s, int v)
//{
//	int* newarray = newDynamic1D(s+1);
//	copy(newarray,oldarray,s);
//	newarray[s] = v;
//	s++;
//	delete[]oldarray;
//	return newarray;
//}
//void copy(int* newarray, int* oldarray, int s)
//{
//	for (int i = 0; i < s; i++)
//	{
//		newarray[i] = oldarray[i];
//	}
//}
//void display(int* p, int s)
//{
//	for (int i = 0; i < s; i++)
//	{
//		cout << p[i] <<  " ";
//	}
//}
//void deleteDynamic1D(int* p)
//{
//	delete[]p;
//}