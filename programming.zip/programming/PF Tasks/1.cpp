#include<iostream>
using namespace std;

int* resize(int*p,int&s);
void copy(int*N,int*O,int s);

int main1()
{
	int s = 10;
	int* arr = new int[s];
	for (int i = 0; i < s; i++)
	{
		arr[i] = i+1;
		cout << arr[i] << " ";
	}
	cout << endl;
	int* p = resize(arr, s);
	for (int i = 0; i < s; i++)
	{
		cout << p[i]<<" ";
	}
	system("pause");
	return 0;
}
int* resize(int* p, int& s)
{
	int* newAr = new int[s+1];
	copy(newAr,p,s);
	newAr[s] = 11;
	s++;
	delete[]p;
	return newAr;
}
void copy(int* N, int* O, int s)
{
	for (int i = 0; i < s; i++)
	{
		N[i] = O[i];
	}
}