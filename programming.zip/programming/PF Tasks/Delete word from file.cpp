//#include<iostream>
//#include<fstream>
//
//using namespace std;
//
//bool comp(char arr[],char arr1[]);
//
//int main()
//{
//	//file names
//	const char* tempname = "temp.txt";
//	const char* filename = "input1.txt";
//	ifstream read;//to read file
//	read.open(filename);
//	if (!read)//check if not read
//	{
//		cout << "File not found!...\n";
//	}
//	else
//	{
//		ofstream temp;//temp write
//		temp.open(tempname);
//		char arr[100];
//		char arr1[100];
//		cout << "Enter a word to remove from file: ";
//		cin.getline(arr1,100);//choose word to remove
//		cout << "After removing word from File is: ";
//		int i = 0;
//		while (read>>arr)
//		{
//			if (comp(arr,arr1))//check that word to remove from file
//			{
//				temp << "";
//			}
//			else
//			{
//				temp << arr <<" ";
//				cout << arr <<" ";
//			}
//			i++;
//		}
//		read.close();
//		temp.close();
//		remove(filename);//remove oldfile
//		rename(tempname,filename);//rename tempfile with oldfile
//	}
//	return 0;
//	
//}
//bool comp(char arr[], char arr1[])//to compare specific word in array
//{
//	int i = 0;
//	int sum1 = 0, sum2 = 0;
//	while (arr[i]!='\0'&&arr1[i]!='\0')
//	{
//		sum1 += arr[i];
//		sum2 += arr1[i];
//		if (arr[i]!=arr1[i])
//		{
//			false;
//		}
//		i++;
//	}
//	return sum1 == sum2;
//}