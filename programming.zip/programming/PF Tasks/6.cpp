#include<iostream>
using namespace std;

const int row = 6;
const int col = 6;

void input(int arr[row][col], int row, int col);
int EvenSum(int arr[row][col], int row, int col);
int OddSum(int arr[row][col], int row, int col);
void display(int arr[row][col], int row, int col);

int main6()
{
	int A[row][col];
	cout << "Enter the Vlaues of " << row << " by " << col << " Matrix" << ":\n";
	input(A, row, col);
	cout << "\nMatrix is:\n";
	display(A, row, col);
	cout << "\nSum of all Even element in given matrix is: " << EvenSum(A, row, col);
	cout << "\nSum of all Odd element in given matrix is: " << OddSum(A, row, col) << endl;
	system("pause");
	return 0;
}
void input(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << "Enter a value for Location (" << i << "," << j << "):";
			cin >> arr[i][j];
		}
	}
}
int EvenSum(int arr[row][col], int row, int col)
{
	int sum1 = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (arr[i][j] % 2 == 0)
			{
				sum1 += arr[i][j];
			}
		}
	}
	return sum1;
}
int OddSum(int arr[row][col], int row, int col)
{
	int sum1 = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (arr[i][j]%2!=0)
			{
				sum1 += arr[i][j];
			}
		}
	}
	return sum1;
}
void display(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (cout << arr[i][j])
			{
				cout << " ";
			}
			else
			{
				cout << "  ";
			}
		}
		cout << endl;
	}
}