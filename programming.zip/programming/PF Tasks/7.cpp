#include<iostream>
using namespace std;

const int row = 4;
const int col = 6;

void input(int arr[row][col], int row, int col);
void Row_Sum(int arr[row][col], int row, int col);
void display(int arr[row][col], int row, int col);

int main7()
{
	int A[row][col];
	cout << "Enter the Vlaues of " << row << " by " << col << " Matrix" << ":\n";
	input(A, row, col);
	cout << "\nMatrix is:\n";
	display(A, row, col);
	cout << endl;
	Row_Sum(A, row, col);
	system("pause");
	return 0;
}
void input(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << "Enter a value for Location (" << i << "," << j << "):";
			cin >> arr[i][j];
		}
	}
}
void Row_Sum(int arr[row][col], int row, int col)
{
	cout << "Row wise sum of this array is:\n";
	for (int i = 0; i < row; i++)
	{
		int sum = 0;
		for (int j = 0; j < col; j++)
		{
			sum += arr[i][j];
			cout << arr[i][j] << " ";
		}
		cout <<" (Sum of row " <<i+1<<" is: " << sum <<")"<< endl;
	}
}
void display(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (cout << arr[i][j])
			{
				cout << " ";
			}
			else
			{
				cout << "  ";
			}
		}
		cout << endl;
	}
}