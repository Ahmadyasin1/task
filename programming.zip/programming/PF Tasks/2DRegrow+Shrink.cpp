#include<iostream>
#include<fstream>
using namespace std;

int row_size(const char* fileName);
void readd(ifstream& read, char** Data, int row, int* col);
char* regrow(char *oldarray,int s, char a);
char* shrink(char* oldarray, int&s, char a);
void copy(char*newarray,char*oldarray,int s);
void shrink2D(char**p,int row,int*col,char ch);
void display(char**p,int row, int*col);

int main()
{
	const char* fileName = "Data.txt";
	ifstream read;
	read.open(fileName);
	int row = row_size(fileName);
	cout << "Total Rows in File are: " << row<<endl;
	cout << "Data in file is:\n";
	int* col = new int[row];
	char** Data=new char*[row];

	if (!read)
	{
		cout << "File not found!...";
	}
	else
	{
		readd(read,Data,row,col);
		display(Data,row,col);
		char ch;
		cout << "\nEnter a chracter to remove: ";
		cin >> ch;
		shrink2D(Data,row,col,ch);
		display(Data, row, col);
	}
	return 0;
}

int row_size(const char* fileName)
{
	ifstream read;
	read.open(fileName);
	if (!read)
	{
		cout << "File Not Found!...";
	}
	else
	{
		char temp;
		int row = 0;
		while (read.get(temp))
		{
			if (temp == '\n')
			{
				row++;
			}
		}
		read.close();
		return row; // Add the return statement here
	}
	return 0;
}
void readd(ifstream& read, char**Data,int row, int *col)
{
	char temp = '\0';
	for (int i = 0; i < row; i++)
	{
		int size = 0;
		read.get(temp);
		while (temp!='\n')
		{
			if (temp==' ')
			{
				read.get(temp);
				continue;
			}
			else
			{
				size++;
				Data[i] = regrow(Data[i],size,temp);
				read.get(temp);
			}
		}
		col[i] = size;
		Data[i][col[i]] = '\0';
	}
}
char* regrow(char* oldarray, int s, char a)
{
	if (s==1)
	{
		oldarray = new char[s];
		oldarray[s-1] = a;
		return oldarray;
	}
	else
	{
		char* newarray = new char[s];
		copy(newarray, oldarray, s - 1);
		newarray[s - 1] = a;
		delete[] oldarray;
		return newarray;
	}
}
void copy(char* newarray, char* oldarray, int s)
{
	for (int i = 0; i < s; i++)
	{
		newarray[i] = oldarray[i];
	}
}
char* shrink(char* oldarray, int& s, char a)
{
	--s;
	char* newarray = new char[s];
	for (int i = a; i < s; i++)
	{
		oldarray[i] = oldarray[i + 1];
	}
	copy(newarray,oldarray,s);
	delete[] oldarray;
	return newarray;
}
void shrink2D(char** p, int row, int* col, char ch)
{
	bool check = false;
	char temp;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col[i]; j++)
		{
			if (ch==p[i][j])
			{
				check = true;
				cout << "Chracter found at index ("<<i<<" , "<<j<<"):\n";
				p[i] = shrink(p[i],col[i],j);
			}
			else
			{
				continue;
			}
		}
	}
	if (check==false)
	{
		cout << "Chracter not found!...";
	}
}
void display(char** p, int row, int* col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col[i]; j++)
		{
			cout << p[i][j]<<" ";
		}
		cout << endl;
	}
}