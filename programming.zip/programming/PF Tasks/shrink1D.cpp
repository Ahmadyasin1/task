//#include<iostream>
//#include<fstream>
//using namespace std;
//
//int* newDynamic1D(int s);
//int* shrink(int* oldarray, int& s, int a);
//void copy(int* newarray, int* oldarray, int s, int k);
//void display(int* p, int s);
//void deleteDynamic1D(int* p);
//
//int main()
//{
//	int* arr = new int[10] {1,2,3,4,5,6,7,8,9,10};
//	int size = 10;
//	for (int i = 0; i < size; i++)
//	{
//		if (!(arr[i] % 2 == 0))
//		{
//			arr = shrink(arr, size, arr[i]);
//		}
//	}
//	display(arr, size);
//	deleteDynamic1D(arr);
//	return 0;
//}
//
//int* newDynamic1D(int s)
//{
//	int* n = new int[s];
//	return n;
//}
//int* shrink(int* oldarray, int& s,int a)
//{
//	int* newarray = newDynamic1D(s - 1);
//	copy(newarray, oldarray, s, a);
//	s--;
//	deleteDynamic1D(oldarray);
//	return newarray;
//}
//void copy(int* newarray, int* oldarray, int s, int k)
//{
//	int j = 0;
//	for (int i = 0; i < s; i++)
//	{
//		if (k != oldarray[i])
//		{
//			newarray[j] = oldarray[i];
//			j++;
//		}
//	}
//}
//void display(int* p, int s)
//{
//	for (int i = 0; i < s; i++)
//	{
//		cout << p[i] << " ";
//	}
//	cout << endl;
//}
//void deleteDynamic1D(int* p)
//{
//	delete[] p;
//}
