#include<iostream>
using namespace std;
int main1()
{
	int a = 0, count = 0;
	char line[100];
	cout << "Entre a string:-\n";
	cin.getline(line, 100);
	while (line[a]!='\0')
	{
		count++;
		a++;
	}
	cout << "Length is: "<<count << endl << "String is: ";
	if (count%2==0)//To check even
	{
		for (int i = a; i >=0; i--)
		{
			cout << line[i];
		}
	}
	else if (count % 2 != 0)//To check odd
	{
		for (int i = 0; i <= a; i++)
		{
			for (int  j = i+1; j < a+1; j++)
			{
				if (line[i]>line[j])//To sort array
				{
					int temp = line[i];
					line[i] = line[j];
					line[j] = temp;
				}
			}
		}
		for (int i = 0; i <= a; i++)
		{
			cout << line[i];
		}
	}
	return 0;
}