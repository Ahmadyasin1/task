#include<iostream>
#include<fstream>
using namespace std;

int main3()
{
	ifstream read;
	read.open("students.txt");
	if (!read)
	{
		cout << "File not Found";
	}
	else
	{
		ofstream write;
		write.open("record.txt");
		write << "Semester\t \tProgram\t \tRoll_No." << endl;
		cout << "Semester\t \tProgram\t \tRoll_No." << endl;
		for (int i = 0; i < 5; i++)
		{
			char arr[100],smester[100], program[100], Roll_NO[100];
			read.get(smester,5);
			read.get(arr, 2);
			read.get(program,4);
			read.get(arr, 2);
			read.getline(Roll_NO, 5);
			write << smester << "\t\t\t" << program << "\t\t\t" << Roll_NO << endl;
			cout << smester << "\t\t\t" << program << "\t\t" << Roll_NO << endl;
		}
		read.close();
		write.close();
	}
	return 0;
}