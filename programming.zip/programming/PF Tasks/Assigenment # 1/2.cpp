#include <iostream>
#include <fstream>
#include<string>
using namespace std;
int main()
{
	ifstream read;
	read.open("input.txt");
	ofstream write;
	write.open("output.txt");
	if (!read)
	{
		cout << "File not found";
	}
	else
	{
		string line;
		int a = 0, cou_vo = 0, cou_co = 0, cou_a = 0, cou_e = 0, cou_i = 0, cou_o = 0, cou_u = 0;
		getline(read, line);
		while (line[a] != '\0')
		{
			if (line[a] == 'A' || line[a] == 'E' || line[a] == 'I' || line[a] == 'O' || line[a] == 'U' || line[a] == 'a' || line[a] == 'e' || line[a] == 'i' || line[a] == 'o' || line[a] == 'u')//count vowels
			{
				cou_vo++;
			}
			if ((line[a] >= 65 && line[a] <= 90) || (line[a] >= 97 && line[a] <= 122))
			{
				if (!(line[a] == 'A' || line[a] == 'E' || line[a] == 'I' || line[a] == 'O' || line[a] == 'U' || line[a] == 'a' || line[a] == 'e' || line[a] == 'i' || line[a] == 'o' || line[a] == 'u'))//count consonats
				{
					cou_co++;
				}
			}
			if (line[a] == 'A' || line[a] == 'a')
			{
				cou_a++;
			}
			if (line[a] == 'E' || line[a] == 'e')
			{
				cou_e++;
			}
			if (line[a] == 'I' || line[a] == 'i')
			{
				cou_i++;
			}
			if (line[a] == 'O' || line[a] == 'o')
			{
				cou_o++;
			}
			if (line[a] == 'U' || line[a] == 'u')
			{
				cou_u++;
			}
			a++;
		}
		int array[5] = {cou_a, cou_e, cou_i, cou_o, cou_u};
		for (int i = 0; i <= 5; i++)
		{
			for (int j = i + 1; j < 5; j++)
			{
				if (array[i] < array[j])
				{
					int temp = array[i];
					array[i] = array[j];
					array[j] = temp;
				}
			}
		}
		cout << "Total Consonants: " << cou_co << endl;
		write << "Total Consonants: " << cou_co << endl;
		cout << "Total Vowels: " << cou_vo << endl;
		write << "Total Vowels: " << cou_vo << endl;
		for (int i = 0; i < 5; i++)
		{
			if (cou_a==array[i])
			{
				cout << "Toatl 'a' : " << array[i] << endl;
				write << "Toatl 'a' : " << array[i] << endl;
			}
			else if (cou_e == array[i])
			{
				cout << "Toatl 'e' : " << array[i] << endl;
				write << "Toatl 'e' : " << array[i] << endl;
			}
			else if (cou_i == array[i])
			{
				cout << "Toatl 'i' : " << array[i] << endl;
				write << "Toatl 'i' : " << array[i] << endl;
			}
			else if (cou_o == array[i])
			{
				cout << "Toatl 'o' : " << array[i] << endl;
				write << "Toatl 'o' : " << array[i] << endl;
			}
			else if (cou_u == array[i])
			{
				cout << "Toatl 'u' : " << array[i] << endl;
				write << "Toatl 'u' : " << array[i] << endl;
			}
		}
	}
	return 0;
}