#include<iostream>
using namespace std;

const int row = 3;
const int col = 3;

void input(int arr[row][col], int row, int col);
void display(int arr[row][col], int row, int col);

int main4()
{
	int A[row][col];
	cout << "Enter the Vlaues of " << row << " by " << col << " Matrix" << ":\n";
	input(A, row, col);
	cout << "\nMatrix is:\n";
	display(A, row, col);
	system("pause");
	return 0;
}
void input(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << "Enter a value for Location (" << i << "," << j << "):";
			cin >> arr[i][j];
		}
	}
}
void display(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (cout << arr[i][j])
			{
				cout << " ";
			}
			else
			{
				cout << "  ";
			}
		}
		cout << endl;
	}
}