//#include<iostream>
//#include<fstream>
//using namespace std;
//
//int* newDynamic1D(int s);
//int* shrink(int* oldarray, int& s);
//void copy(int* newarray, int* oldarray, int s);
//void display(int* p, int s);
//void deleteDynamic1D(int* p);
//
//int main()
//{
//	int a,s=10,c=1;
//	int* array = newDynamic1D(s);
//	for (int i = 0; i < s; i++)
//	{
//		array[i] = c++;
//	}
//	cout << "Enter a Specific position to delete from an array: ";
//	cin >> a;
//	for (int i = a; i < 10; i++)
//	{
//		array[i] = array[i + 1];
//	}
//	array=shrink(array,s);
//	cout << "After Deleteing from that position: ";
//	display(array,s);
//	return 0;
//}
//
//int* newDynamic1D(int s)
//{
//	int* n = new int[s];
//	return n;
//}
//int* shrink(int* oldarray, int& s)
//{
//	int* newarray = newDynamic1D(s - 1);
//	s--;
//	copy(newarray, oldarray, s);
//	delete[]oldarray;
//	return newarray;
//}
//void copy(int* newarray, int* oldarray, int s)
//{
//	for (int i = 0; i < s; i++)
//	{
//		newarray[i] = oldarray[i];
//	}
//}
//void display(int* p, int s)
//{
//	for (int i = 0; i < s; i++)
//	{
//		cout << p[i] << " ";
//	}
//}
//void deleteDynamic1D(int* p)
//{
//	delete[]p;
//}