//#include <iostream>
//using namespace std;
//
//int** New_Dynamic_J(int row,int*col);
//void input(int **p,int row,int *col);
//void row_wise_sum(int** p, int row, int* col);
//void col_wise_sum(int** p, int row, int* col);
//void display(int** p, int row, int* col);
//void delete_J(int** p, int row, int* col);
//
//int main()
//{
//	int row = 3;
//	int* col =new int[row];
//	int** p = New_Dynamic_J(row,col);
//	input(p,row,col);
//	cout << "\nMatrix of Jagged array is:\n";
//	display(p, row, col);
//	cout << "\nRow wise sum of above matrix is:\n";
//	row_wise_sum(p, row, col);
//	cout << "\nCol wise sum of above matrix is:\n";
//	col_wise_sum(p, row, col);
//	//Delete jagged array
//	delete_J(p, row, col);
//	system("pause");
//	return 0;
//}
//int** New_Dynamic_J(int row, int* col)
//{
//	int** p = new int*[row];
//	for (int i = 0; i < row; i++)
//	{
//		cout << "Enter column for row "<<i+1<<": ";
//		cin >> col[i];
//		p[i] = new int[col[i]];
//	}
//	return p;
//}
//
//void input(int** p, int row, int* col)
//{
//	int c = 1;
//	cout << "Enter values for Jagged array:\n";
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col[i]; j++)
//		{
//			p[i][j] = c++;
//		}
//	}
//}
//
//void row_wise_sum(int** p, int row, int* col)
//{
//	
//	for (int i = 0; i < row; i++)
//	{
//		int sum = 0;
//		for (int j = 0; j < col[i]; j++)
//		{
//			sum += p[i][j];
//			cout << p[i][j]<<" ";
//		}
//		cout << " Sum of Row " << i + 1 << " is: " << sum << endl;
//	}
//}
//void col_wise_sum(int** p, int row, int* col)
//{
//	int maxCols = 0;
//
//	// Find the maximum number of columns
//	for (int i = 0; i < row; i++)
//	{
//		if (col[i] > maxCols)
//		{
//			maxCols = col[i];
//		}
//	}
//
//	for (int i = 0; i < maxCols; i++)
//	{
//		int sum = 0;
//		for (int j = 0; j < row; j++)
//		{
//			if (i < col[j])
//			{
//				sum += p[j][i];
//				cout << p[j][i] << " ";
//			}
//		}
//		cout << " Sum of column " << i + 1 << " is: " << sum << endl;
//	}
//}
//void display(int** p, int row, int* col)
//{
//	for (int i = 0; i < row; i++)
//	{
//		for (int j = 0; j < col[i]; j++)
//		{
//
//			cout << p[i][j]<<" ";
//		}
//		cout << endl;
//	}
//}
//void delete_J(int** p, int row, int* col)
//{
//	for (int i = 0; i < row; i++)
//	{
//		delete[]p[i];
//		p[i] = 0;
//	}
//	delete[]p;
//	p = 0;
//}