#include <iostream>
using namespace std;

char** new_dynamic(int row, int col);
void displayBoard(char** board);
bool checkWin(char** board, char player);
bool checkDraw(char** board);
int getPlayerMove(char** board);
void resetGame(char**& board, char& currentPlayer, bool& gameFinished);
void delete_dynamic(char** board);

int main()
{
    char**board= new_dynamic(3,3);
    //Take inputs for board 1 to 9
    char c = '1';
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            board[i][j] = c;
            c++;
        }
    }

    char player1[100], player2[100];//Declare variables for two players name
    char currentPlayer = 'X';
    bool gameFinished = false;

    cout << "Welcome to Tic-Tac-Toe!" << endl;
    //Take inputs of names from user
    cout << "Player 1, enter your name: ";
    cin >> player1;
    cout << "Player 2, enter your name: ";
    cin >> player2;
    //use while loop to play again and again
    while (!gameFinished)
    {
        system("cls");
        displayBoard(board);
        cout << endl << "Taking Turns:" << endl;
        cout << currentPlayer << "'s turn." << endl;

        int cell = getPlayerMove(board);
        int row = (cell - 1) / 3;
        int col = (cell - 1) % 3;
        board[row][col] = currentPlayer;

        if (checkWin(board, currentPlayer))
        {
            system("cls");
            displayBoard(board);
            cout << endl << "Congratulations, " << (currentPlayer == 'X' ? player1 : player2) << "! You won the game!" << endl;
            gameFinished = true;
        }
        else if (checkDraw(board))
        {
            system("cls");
            displayBoard(board);
            cout << endl << "It's a draw! No winner in this game." << endl;
            gameFinished = true;
        }
        else
        {
            currentPlayer = (currentPlayer == 'X' ? 'O' : 'X');
        }
    }
    cout << "Do you want to play again? (yes/no): ";
    char playAgain;
    cin >> playAgain;
    if (playAgain == 'Y' || playAgain == 'y')
    {
        resetGame(board, currentPlayer, gameFinished);
        main();
    }
    else
    {
        cout << "Goodbye! Thanks for playing." << endl;
    }
    delete_dynamic(board);
    return 0;
}

char** new_dynamic(int row, int col)
{
    //creat Board of 3 by 3 matrix using 2D dynamic array
    char** temp = new char* [3];//2D dynamic array
    for (int i = 0; i < 3; i++)
    {
        temp[i] = new char[3];
    }
    return temp;
}
void displayBoard(char** board)
{
    cout << "Current board:" << endl;
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
            cout << board[i][j] << " ";
        cout << endl;
    }
}
bool checkWin(char** board, char player)
{
    //check row wise
    for (int i = 0; i < 3; i++)
    {
        if (board[i][0] == player && board[i][1] == player && board[i][2] == player)
            return true;
    }
    //check coloumn wise
    for (int i = 0; i < 3; i++)
    {
        if (board[0][i] == player && board[1][i] == player && board[2][i] == player)
            return true;
    }
    //check diagnol
    if (board[0][0] == player && board[1][1] == player && board[2][2] == player)
        return true;
    //check odd diagnol
    if (board[0][2] == player && board[1][1] == player && board[2][0] == player)
        return true;
    return false;
}
bool checkDraw(char** board)
{
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            if (board[i][j] != 'X' && board[i][j] != 'O')
                return false;
        }
    }
    return true;
}
int getPlayerMove(char** board)
{
    int cell;
    while (true)
    {
        cout << "Enter the cell number to mark (1-9): ";
        cin >> cell;

        if (cell > 9 && cell < 0)
        {
            cout << "Invalid input. Please enter a valid cell number." << endl;
            continue;
        }

        //check if already marked cell
        int row = (cell - 1) / 3;
        int col = (cell - 1) % 3;
        if (board[row][col] == 'X' || board[row][col] == 'O')
        {
            cout << "That cell is already marked. Choose another cell." << endl;
            continue;
        }
        break;
    }
    return cell;
}
void resetGame(char**& board, char& currentPlayer, bool& gameFinished)
{
    //Delete dynamic array
    delete_dynamic(board);
    // create new board
    new_dynamic(3, 3);
    char c = '1';
    for (int i = 0; i < 3; i++)
    {
        for (int j = 0; j < 3; j++)
        {
            board[i][j] = c;
            c++;
        }
    }

    currentPlayer = 'X';
    gameFinished = false;
}
void delete_dynamic(char** board)
{
    // Deallocate the old board memory
    for (int i = 0; i < 3; i++)
    {
        delete[] board[i];
    }
    delete[] board;
}