#include<iostream>
using namespace std;
int sum(int a, int b)
{
	int sum1;
	sum1 = a + b;
	return sum1;
}
int sub(int a, int b)
{
	int sub1;
	sub1 = a - b;
	return sub1;
}
int product(int a, int b)
{
	int product1;
	product1 = a * b;
	return product1;
}
int divide(int a, int b)
{
	int divide1;
	divide1 = a / b;
	return divide1;
}
int main1()
{
	char abc;
	cout << "Please let us which opration do you want to perform '+ , - , * , /':- ";
	cin >> abc;
	int num1, num2;
	int add, subt, prod, Div;
	cout << "Please enter two numbers:-\n";
	cin >> num1 >> num2;
	switch (abc)
	{
	case '+':
		add = sum(num1, num2);
		cout << "Sum of two values are:- " << add;
		break;
	case '-':
		subt = sub(num1, num2);
		cout << "Subtraction of two values are:- " << subt;
		break;
	case '*':
		prod = product(num1, num2);
		cout << "Product of two values are:- " << prod;
		break;
	case '/':
		Div = divide(num1, num2);
		cout << "Divide of two values are:- " << Div;
		break;
	}
	return 0;
}
