#include<iostream>
using namespace std;
int positive(int arr[],int siz)
{
	int count = 0;
	for (int i = 0; i < siz; i++)
	{
		if (arr[i]>=0)
		{
			count++;
		}
	}
	return count;
}
int main5()
{
	cout << "Please enter an array:\n";
	int array[10],res;
	for (int i = 0; i < 10; i++)
	{
		cin >> array[i];
	}
	res = positive(array,10);
	cout << "Positive numbers in this array are:- " << res;
	return 0;
}