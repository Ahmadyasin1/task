#include<iostream>
using namespace std;
void table(int ab)
{
	for (int i = 1; i <= 10; i++)
	{
		cout << ab <<" * " << i << " = " << ab*i;
		cout << endl;
	}
}
float Diameter(float r)
{
	float re;
	re = (2 * r);
	return re;
}
float Circumference(float r)
{
	float re1;
	re1 = (2 * 3.14 * r);
	return re1;
}
float Area(float r)
{
	float re2;
	re2 = (3.14*r*r);
	return re2;
}
int main()
{
	int abc;
	cout << "Please enter a number to write a table: ";
	cin >> abc;
	table(abc);
	float a,res;
	cout << "Enter a number: ";
	cin >> a;
	res=Diameter(a);
	cout << "Diameter is: " << res << endl;
	res = Circumference(a);
	cout << "Circumference is: " << res << endl;
	res = Area(a);
	cout << "Area is: "<<res;
	return 0;
}