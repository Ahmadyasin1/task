#include<iostream>
using namespace std;
int fact(int a)
{
	int ab=1;
	for (int i = a; i>=1; i--)
	{
		ab *= i;
	}
	return ab;
}
int main4()
{
	int fac,res;
	cout << "Enter a number to find factorial: ";
	cin >> fac;
	res = fact(fac);
	cout << "Factorial is: " << res << endl;
	return 0;
}