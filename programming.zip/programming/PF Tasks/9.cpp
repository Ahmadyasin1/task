#include<iostream>
using namespace std;

const int row = 3;
const int col = 3;

void input(int arr[row][col], int row, int col);
int Sum(int arr[row][col], int row, int col);
void display(int arr[row][col], int row, int col);

int main9()
{
	int A[row][col];
	cout << "Enter the Vlaues of " << row << " by " << col << " Matrix" << ":\n";
	input(A, row, col);
	cout << "\nMatrix is:\n";
	display(A, row, col);
	cout << "Sum of all element in given matrix is: " << Sum(A, row, col) << endl;
	system("pause");
	return 0;
}
void input(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			cout << "Enter a value for Location (" << i << "," << j << "):";
			cin >> arr[i][j];
		}
	}
}
int Sum(int arr[row][col], int row, int col)
{
	int sum1 = 0;
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			sum1 += arr[i][j];
		}
	}
	return sum1;
}
void display(int arr[row][col], int row, int col)
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			if (cout << arr[i][j])
			{
				cout << " ";
			}
			else
			{
				cout << "  ";
			}
		}
		cout << endl;
	}
}